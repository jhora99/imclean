#! /bin/bash

# 2020/03/05                              Joseph Hora
#
# recompile all c programs needed for the imclean script
#
# The final part moves the executables to the bin directory;
# change this as needed to move the files to where you want

cc bandcor.c swapbytes.c fitsio.c -lm -O3 -o bandcor
cc bandcor_warm.c swapbytes.c fitsio.c -lm -O3 -o bandcor_warm
cc  bleedcor.c swapbytes.c fitsio.c -lm -O3 -o bleedcor 
cc chanassmbl.c swapbytes.c fitsio.c -lm -O3 -o chanassmbl
cc chanslice.c swapbytes.c fitsio_cs.c -lm -O3 -o chanslice
cc pixcorrect.c swapbytes.c fitsio.c -lm -O3 -o pixcorrect
cc colcorrect.c swapbytes.c fitsio.c -lm -O3 -o colcorrect
cc maskblock.c swapbytes.c fitsio.c -lm -O3 -o maskblock
cc rowcorrect.c swapbytes.c fitsio.c -lm -O3 -o rowcorrect

strip bandcor
strip bandcor_warm
strip bleedcor
strip chanassmbl
strip chanslice
strip pixcorrect
strip colcorrect
strip maskblock
strip rowcorrect

mv bandcor ../bin
mv bandcor_warm ../bin
mv bleedcor ../bin
mv chanassmbl ../bin
mv chanslice ../bin
mv pixcorrect ../bin
mv colcorrect ../bin
mv maskblock ../bin
mv rowcorrect ../bin



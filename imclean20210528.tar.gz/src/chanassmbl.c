/*************************************************************************/
/*                                                      Joseph L. Hora   */
/* chanassmb.c - Assemble a  FITS image from the sliced images           */
/*               The original image is overwritten with the assembled    */
/*************************************************************************/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include "fiocom.h"

#define TRUE 1
#define FALSE 0


static float image[XPIX][YPIX];    
static float im2[XPIX][YPIX];    
/*  These functions are in fitsio.c */
char * add_card();
char * replace_card();
char * build_card();
char * build_card2();
char * build_comment();
char * init_fitshead();
int src_fhead();

main(ac, av)           /***********Main program start**********/
int ac;
char *av[];
{
   char loop,found1,found2,vbuf[85],fname[255],rootname[255],
         buf[85];
   struct BUFFER imhead,timhead;
   struct fhead_t *fhbuf,*tfhbuf;
   double factor,sigma,sum, avg,sumsq;
   char *cptr;

   int   i,j, ifile,k, l,lineno;
   FILE *fp1,*fp2;
   int xsize;

/*  Initialize parameter values  */

   strcpy(fname,"NONE");
   strcpy(rootname,"NONE");
   
/*    If enough command line parameters have been entered, read them in    */
   if (ac <2)
   {
      printf("  Enter file name on command line\n");
      exit(0);
   }
 for (ifile=1; ifile<ac; ++ifile)
{
   sscanf(av[ifile],"%s",fname);
   if (readfits(fname,&imhead,image)!=0)
   {
      printf("Error reading FITS file, program terminating.\n");
      exit(1);
   }
printf("filename: %s, length=%i\n",fname,strlen(fname));

   strcpy(rootname,fname);
   rootname[strlen(fname)-5]=rootname[strlen(fname)];
   strcat(rootname,".a.fits");
 
   if (readfits(rootname,&timhead,im2)!=0)
   {
      printf("Error reading FITS file: %s\n",rootname);
      exit(1);
   }


   for (i=0; i<imhead.naxis1; i+=4)
      for (j=0; j<imhead.naxis2; j++)
          image[i][j] = im2[(int)(i/4)][j];

   rootname[strlen(rootname)-6]='b';
   if (readfits(rootname,&timhead,im2)!=0)
   {
      printf("Error reading FITS file: %s\n",rootname);
      exit(1);
   }

   for (i=1; i<imhead.naxis1; i+=4)
      for (j=0; j<imhead.naxis2; j++)
          image[i][j] = im2[(int)(i/4)][j];

   rootname[strlen(rootname)-6]='c';
   if (readfits(rootname,&timhead,im2)!=0)
   {
      printf("Error reading FITS file: %s\n",rootname);
      exit(1);
   }

   for (i=2; i<imhead.naxis1; i+=4)
      for (j=0; j<imhead.naxis2; j++)
          image[i][j] = im2[(int)(i/4)][j];

   rootname[strlen(rootname)-6]='d';
   if (readfits(rootname,&timhead,im2)!=0)
   {
      printf("Error reading FITS file: %s\n",rootname);
      exit(1);
   }

   for (i=3; i<imhead.naxis1; i+=4)
      for (j=0; j<imhead.naxis2; j++)
          image[i][j] = im2[(int)(i/4)][j];

   writefits(fname,&imhead,image);

/*  free up memory for fits buffer: original FITS header lines are discarded,
    but the parameters such as naxis, bitpix, etc. are saved. */

   free_buffer(&imhead);
   free_buffer(&timhead);
}

   exit(0);
 

}     /************************* End main *************************************/

/*************************************************************************/
/*                                                      Joseph L. Hora   */
/* bleedcor.c - correct muxbleed in IRAC images                          */
/*************************************************************************/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include "fiocom.h"

#define TRUE 1
#define FALSE 0


static float image[XPIX][YPIX],newim[XPIX][YPIX];
int maxi();
int mini();
float median();


main(argc, argv)           /***********Main program start**********/
int argc;
char *argv[];
{
   char  allfix,specify,interpolate,loop,found1,found2,fname[80],rootname[80];
   struct BUFFER imhead;
   struct fhead_t *fhbuf;
   double factor,sigma,sum, avg,sumsq;
   float medval,medval2;

   int   ll,jsz, ii,jj,m, n, idx,i,j, k, l,imin,imax,jmin,jmax,ifile;
   float stat[16384];
   FILE *fp1,*fp2;
   double checksum;

   allfix=specify=FALSE;

/*  Initialize parameter values  */

   strcpy(fname,"NONE");
   
/*    If enough command line parameters have been entered, read them in    */
   if (argc <2)
   {
      printf("  bleedcor: correct IRAC mux bleed (channels 1 and 2)\n\n");
      printf("    usage:  bleedcor -B imin imax jmin jmax image.fits\n\n");
      printf("    -b imin imax jmin jmax     specify limits of region to \n");
      printf("                               correct, only one amplifier (imin)\n");
      printf("    -B imin imax jmin jmax     specify limits of region, fix\n");
      printf("                                all 4 amplifiers\n"); 
      exit(0);
   }
  for (ifile=1; ifile<argc; ++ifile)
  {
    sscanf(argv[ifile],"%s",fname);
 
    if (fname[0]=='-')
    {
       switch (fname[1])
       {
          case 'b':
            sscanf(argv[++ifile],"%i",&imin);
            sscanf(argv[++ifile],"%i",&imax);
            sscanf(argv[++ifile],"%i",&jmin);
            sscanf(argv[++ifile],"%i",&jmax);
            specify=TRUE;
            break;
          case 'B':
            sscanf(argv[++ifile],"%i",&imin);
            sscanf(argv[++ifile],"%i",&imax);
            sscanf(argv[++ifile],"%i",&jmin);
            sscanf(argv[++ifile],"%i",&jmax);
            allfix=TRUE;
            specify=TRUE;
            break;
       }
 
    }
    else
    {
    if (readfits(fname,&imhead,image)!=0)
    {
      printf("Error reading FITS file, program terminating.\n");
      exit(1);
   }


   if (!specify)
   {
      printf("Error - must specify limits with -B or -b\n");
      exit(1);
      imin=0; jmin=0;
      imax=imhead.naxis1;
      jmax=imhead.naxis2;
   } else {
      imin=max(1,min(imin,imhead.naxis1));
      jmin=max(1,min(jmin,imhead.naxis2));
      imax=max(1,min(imax,imhead.naxis1));
      jmax=max(1,min(jmax,imhead.naxis2));
   }
   jsz=jmax-jmin+1;

   for (ll=0; ll<4; ll++)
   {
   ii=imin-1;
      for (jj=jmin-1; jj<jmax; jj++)
      {
        idx=0;
        for(m=ii+ll; m<min(imhead.naxis1,imax); m=m+4)
           stat[idx++]=image[m][jj-2-jsz];
        medval2=median(stat,idx);

        idx=0;
        for(m=ii+ll; m<min(imhead.naxis1,imax); m=m+4)
           stat[idx++]=image[m][jj]-medval2*0.3*(1+exp(-0.065*((m-ii-ll+1)/4+10)));
        medval=median(stat,idx);

        medval=medval2 - medval;
printf("%f %f %i %i\n",medval,medval2,ii,jj);

        for (i=ii+ll; i<imhead.naxis1+1; i=i+4)
        {
           image[i][jj]+=medval-medval2*0.3*(1+exp(-0.065*((i-ii-ll+1)/4+10)));
        }
      }
      if (!allfix)
         ll=4;
   }
         
   writefits(fname,&imhead,image);
/*  free up memory for fits buffer: original FITS header lines are discarded,
    but the parameters such as naxis, bitpix, etc. are saved. */

   free_buffer(&imhead);

   }
   }
   exit(0);
 

}     /************************* End main *************************************/
int max(i1,i2)
int i1;
int i2;
{
    if (i1<i2)
        return i2;
    else
        return i1;
}

int min(i1,i2)
int i1;
int i2;
{
    if (i1<i2)
        return i1;
    else
        return i2;
}

float median(a,inum)
float a[];
int inum;
{
    float c[16384],b[16384],l;
    int i,j,k,n,m;

    n=inum;
    for (i=0; i<n; i++)
     b[i]=a[i];

    k=0;
    while (n>1)
    {
       l=b[0]; m=0;
       for (i=0; i<n; i++)
          if (b[i]<l)
          {
             l=b[i];
             m=i;
          }
       c[k++]=l;
       for (i=m; i<n-1; i++)
          b[i]=b[i+1];
       n--;
       if (n==1)
          c[k]=b[0];
    }
    n=inum/2;
    return(c[n]);
     
}

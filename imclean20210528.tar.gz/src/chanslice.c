/*************************************************************************/
/*                                                      Joseph L. Hora   */
/* chanslice.c - slice the different channels into separate FITS images  */
/*                                                                       */
/*   to compile, use:                                                    */
/*      cc chanslice.c fitsio_cs.c swapbytes.c -lm -o chanslice          */
/*                                                                       */
/*************************************************************************/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include "fiocom.h"

#define TRUE 1
#define FALSE 0


static float image[XPIX][YPIX];    
static float im2[XPIX][YPIX];    
/*  These functions are in fitsio.c */
char * add_card();
char * replace_card();
char * build_card();
char * build_card2();
char * build_comment();
char * init_fitshead();
int src_fhead();

main(argc, argv)           /***********Main program start**********/
int argc;
char *argv[];
{
   char  specify,interpolate,loop,found1,found2,vbuf[85],fname[80],rootname[80],
         buf[85],outname[85];
   struct BUFFER imhead;
   struct fhead_t *fhbuf;
   double factor,sigma,sum, avg,sumsq;
   char *cptr;

   int   i,j, k, l,lineno;
   FILE *fp1,*fp2;
   int xsize;

/*  Initialize parameter values  */

   strcpy(fname,"NONE");
   interpolate=specify = FALSE;
   
/*    If enough command line parameters have been entered, read them in    */
   if (argc >=2)
   {
      sscanf(argv[1],"%s",fname);
   }
   else 
   {
      printf("  Enter file name on command line");
      exit(0);
   }
   if (readfits(fname,&imhead,image)!=0)
   {
      printf("Error reading FITS file, program terminating.\n");
      exit(1);
   }

   xsize = imhead.naxis1;
   imhead.naxis1= xsize /4;
   fhbuf = imhead.fhead;
   lineno = src_fhead(imhead.fhead,"NAXIS1", buf, sizeof(buf));
   if (lineno<1)
   {
      printf("chanslice: error, NAXIS keyword not found\n");
      exit(1);
   }

   cptr = (char *)imhead.fhead->buf;

   cptr += (lineno-1)*80;
   sprintf(vbuf,"%d",imhead.naxis1);
   cptr = build_card( cptr, "NAXIS1", vbuf,
        "PIXELS ON 1ST MOST VARYING AXIS",&imhead);
   imhead.fhead= fhbuf;
   sprintf(vbuf,"%d",1);
   cptr = add_card(cptr,"ZPREMPCH",vbuf,"PREAMP CHANNEL NUMBER (1-4)",&imhead);

   for (i=0; i<xsize; i+=4)
      for (j=0; j<imhead.naxis2; j++)
          im2[(int)(i/4)][j] = image[i][j];
   strncpy(outname,fname, strlen(fname)-5);
   outname[strlen(fname)-5] = 0;
   strcpy(rootname,".a.fits");
   strcat(outname,rootname);
   writefits(outname,&imhead,im2);
   printf("%s\n",outname);

   sprintf(vbuf,"%d",2);
   cptr = replace_card(cptr,"ZPREMPCH",vbuf,"PREAMP CHANNEL NUMBER (1-4)",&imhead);
   for (i=1; i<xsize; i+=4)
      for (j=0; j<imhead.naxis2; j++)
          im2[(int)(i/4)][j] = image[i][j];
   outname[strlen(outname)-6]='b';
   writefits(outname,&imhead,im2);
   printf("%s\n",outname);

   sprintf(vbuf,"%d",3);
   cptr = replace_card(cptr,"ZPREMPCH",vbuf,"PREAMP CHANNEL NUMBER (1-4)",&imhead);
   for (i=2; i<xsize; i+=4)
      for (j=0; j<imhead.naxis2; j++)
          im2[(int)(i/4)][j] = image[i][j];
   outname[strlen(outname)-6]='c';
   writefits(outname,&imhead,im2);
   printf("%s\n",outname);

   sprintf(vbuf,"%d",4);
   cptr = replace_card(cptr,"ZPREMPCH",vbuf,"PREAMP CHANNEL NUMBER (1-4)",&imhead);
   for (i=3; i<xsize; i+=4)
      for (j=0; j<imhead.naxis2; j++)
          im2[(int)(i/4)][j] = image[i][j];
   outname[strlen(outname)-6]='d';
   writefits(outname,&imhead,im2);
   printf("%s\n",outname);

/*  free up memory for fits buffer: original FITS header lines are discarded,
    but the parameters such as naxis, bitpix, etc. are saved. */

   free_buffer(&imhead);

   exit(0);
 

}     /************************* End main *************************************/

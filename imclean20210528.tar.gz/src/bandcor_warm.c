/*************************************************************************/
/*                                                      Joseph L. Hora   */
/* bandcor.c - correct row-wise banding in IRAC images by forcing        */
/*                all rows in box to have the same median                */
/*************************************************************************/
/* compile:  cc bandcor.c fitsio.c  swapbytes.c -lm -o bandcor           */
/*                                                                       */
/*************************************************************************/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include "fiocom.h"

#define TRUE 1
#define FALSE 0


static float image[XPIX][YPIX],newim[XPIX][YPIX];
int maxi();
int mini();
float median();


main(argc, argv)           /***********Main program start**********/
int argc;
char *argv[];
{
   char  specify,FORCE,ROWMODE, COLLIMIT,fname[80],rootname[80];
   struct BUFFER imhead;
   struct fhead_t *fhbuf;
   double factor,sigma,sum, avg,sumsq;
   float medval,medval2,medval3,mean,stddev,d2,cslope,maxpix,med_cs1,med_cs2;

   int   m, n, idx, isize, ihsz,i,j, k, l,imin,imax,jmin,jmax,ifile,
         nfit_max,nfit_min,max_n,ii,Chan;
   float stat[65535];
   FILE *fp1,*fp2;
   double checksum;

   COLLIMIT=FORCE=specify=FALSE;
   ROWMODE=TRUE;
   isize=5;
   Chan=1;

/*  Initialize parameter values  */

   strcpy(fname,"NONE");
   
/*    If enough command line parameters have been entered, read them in    */
   if (argc <2)
   {
      printf("  Enter file name on command line");
      exit(0);
   }
  for (ifile=1; ifile<argc; ++ifile)
  {
    sscanf(argv[ifile],"%s",fname);
 
    if (fname[0]=='-')
    {
       switch (fname[1])
       {
          case 'b':
            sscanf(argv[++ifile],"%i",&imin);
            sscanf(argv[++ifile],"%i",&imax);
            sscanf(argv[++ifile],"%i",&jmin);
            sscanf(argv[++ifile],"%i",&jmax);
            specify=TRUE;
            break;
          case 'a':
            sscanf(argv[++ifile],"%i",&Chan);
            if (Chan>2)
               Chan=2;
            if (Chan<1)
               Chan=1;
            break;
          case 'l':
            COLLIMIT=TRUE;
            break;
          case 'c':
            ROWMODE=FALSE;
            break;
          case 'f':
            FORCE=TRUE;
            break;
       }
 
    }
    else
    {
    if (readfits(fname,&imhead,image)!=0)
    {
      printf("Error reading FITS file, program terminating.\n");
      exit(1);
   }

   isize=min(isize,32);
   ihsz=isize / 2;

   if (!specify)
   {
      printf("Error - must specify limits with -b\n");
      exit(1);
   } else {
      imin=max(0,min(imin,imhead.naxis1));
      jmin=max(0,min(jmin,imhead.naxis2));
      imax=max(0,min(imax,imhead.naxis1));
      jmax=max(0,min(jmax,imhead.naxis2));
      if (imin>imax)
      {
         m=imax;
         imax=imin;
         imin=m;
      }
      if (jmin>jmax)
      {
         m=jmax;
         jmax=jmin;
         jmin=m;
      }
   }

   idx=0;
   mean = d2 = 0;
   if (ROWMODE)
   {
      for(m=max(imin-1,0); m<min(imhead.naxis1,imax); m++)
         for(n=max(jmin-1,0); n<min(imhead.naxis2,jmax); n++)
            stat[idx++]=image[m][n];
      if (idx==0)
      {
         printf("Error - no points\n");
         exit(1);
      }
      medval=median(stat,idx);
      for(n=max(jmin-1,0); n<min(imhead.naxis2,jmax); n++)
      {
         idx=0;
         for(m=max(imin-1,0); m<min(imhead.naxis1,imax); m++)
            stat[idx++]=image[m][n];
         medval2=median(stat,idx);
         mean+=medval2;
         d2+=medval2*medval2;
      }
      mean=mean/(min(imhead.naxis2,jmax)-max(jmin-1,0)+1);
      stddev=sqrt(d2/(min(imhead.naxis2,jmax)-max(jmin-1,0)+1)-mean*mean);
printf("median: %f mean: %f  stddev: %f\n",medval,mean,stddev);
      for(n=max(jmin-1,0); n<min(imhead.naxis2,jmax); n++)
      {
         idx=0;
         for(m=max(imin-1,0); m<min(imhead.naxis1,imax); m++)
            stat[idx++]=image[m][n];
         medval2=median(stat,idx);
printf("%f ",medval2);
         medval3=medval2 - medval;
         if ((fabs(medval3)>stddev/2) || FORCE)
            for (i=0; i<imhead.naxis1; i++)
               image[i][n]-=medval3;
      }
printf("\n");
   }
   else   /* COLUMN MODE */
   {
      idx=0;
      for(m=max(imin-1,0); m<min(imhead.naxis1,imax); m++)
         for(n=max(jmin-1,0); n<min(imhead.naxis2,jmax); n++)
            stat[idx++]=image[m][n];
      if (idx==0)
      {
         printf("Error - no points\n");
         exit(1);
      }
      medval=median(stat,idx);
      for(m=max(imin-1,0); m<min(imhead.naxis1,imax); m++)
      {
         idx=0;
         for(n=max(jmin-1,0); n<min(imhead.naxis2,jmax); n++)
            stat[idx++]=image[m][n];
         medval2=median(stat,idx);
         mean+=medval2;
         d2+=medval2*medval2;
      }
      mean=mean/(min(imhead.naxis1,imax)-max(imin-1,0)+1);
      stddev=sqrt(d2/(min(imhead.naxis1,imax)-max(imin-1,0)+1)-mean*mean);
printf("median: %f mean: %f  stddev: %f\n",medval,mean,stddev);
      for(m=max(imin-1,0); m<min(imhead.naxis1,imax); m++)
      {
         idx=0;
         for(n=max(jmin-1,0); n<min(imhead.naxis2,jmax); n++)
            stat[idx++]=image[m][n];
         medval2=median(stat,idx);
printf("%f ",medval2);

         medval3=medval2 - medval;
         if ((fabs(medval3)>stddev/1.0)|| FORCE) /* If the values are out of 
                                                    range for the area examined,
                                                    do adjustment for whole 
                                                    column  */
         { 
         maxpix=image[m][0];
         max_n=0;
         for(n=0; n<imhead.naxis2; n++)
         {
             if (image[m][n]>maxpix)
             {
                maxpix=image[m][n];
                max_n=n;
             }
         } /* First do region above the peak of the column.  Find the median
              of the columns above the peak, and adjust this to the median of
              the larger region originally selected (medval)  */
         for(n=min(max_n+8,imhead.naxis2); n<imhead.naxis2; n++)
            stat[idx++]=image[m][n];
         medval2=median(stat,idx);
printf("upper section median: %f ",medval2);

         medval3=medval2 - medval;
         for (j=max_n+1; j<imhead.naxis2; j++)
            image[m][j]-=medval3;
                /* Now do region below the peak.  For each column, fit the 
                   median plus a linear function that varies along column */
         idx=0;
         for(n=0; n<min(imhead.naxis2,max_n-4); n++)
            stat[idx++]=image[m][n];
         medval2=median(stat,idx);
printf("lower section median: %f ",medval2);

         medval3=medval2 - medval;
         nfit_min=0;
         nfit_max=max_n-8;
printf("fit min, max range: %i %i\n",nfit_min,nfit_max);
         if (nfit_max-nfit_min<16) {
            for (j=0; j<max_n; j++)
               image[m][j]-=medval3;
         } else {
            idx=0;
            for (ii=nfit_min; ii<nfit_min+8; ii++)
               stat[idx++]=image[m][ii];
            med_cs1=median(stat,idx);
            idx=0;
            for (ii=nfit_max-8; ii<nfit_max; ii++)
               stat[idx++]=image[m][ii];
            med_cs2=median(stat,idx);
            cslope=(med_cs1 - med_cs2 ) / (nfit_max-nfit_min);
printf("cslope: %f\n",cslope);
            if (Chan==2) 
            {
               for (j=0; j<max_n-3; j++)
                  image[m][j]-=(medval3-0.4*cslope*(j));
            }  
            else
            {
               for (j=0; j<max_n-3; j++)
                  image[m][j]-=(medval3-0.7*cslope*(j));
            }
         }
         }
      }
printf("\n");
   }

         
   writefits(fname,&imhead,image);
/*  free up memory for fits buffer: original FITS header lines are discarded,
    but the parameters such as naxis, bitpix, etc. are saved. */

   free_buffer(&imhead);
   }
   }

   exit(0);
 

}   /************************* End main *************************************/
int max(i1,i2)
int i1;
int i2;
{
    if (i1<i2)
        return i2;
    else
        return i1;
}

int min(i1,i2)
int i1;
int i2;
{
    if (i1<i2)
        return i1;
    else
        return i2;
}

float median(a,inum)
float a[];
int inum;
{
    float l,c[65535],b[65535];
    int i,j,k,n,m;

    n=inum;
    for (i=0; i<n; i++)
     b[i]=a[i];

    k=0;
    while (n>1)
    {
       l=b[0]; m=0;
       for (i=0; i<n; i++)
          if (b[i]<l)
          {
             l=b[i];
             m=i;
          }
       c[k++]=l;
       for (i=m; i<n-1; i++)
          b[i]=b[i+1];
       n--;
       if (n==1)
          c[k]=b[0];
    }
    n=inum/2;
    return(c[n]);
     
}

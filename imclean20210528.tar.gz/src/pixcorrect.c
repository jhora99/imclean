/*************************************************************************/
/*                                                      Joseph L. Hora   */
/* pixcorrect.c - interpolate between pixels in a FITS image             */
/*************************************************************************/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include "fiocom.h"

#define TRUE 1
#define FALSE 0


static float image[XPIX][YPIX],newim[XPIX][YPIX];
int maxi();
int mini();
float median();


main(argc, argv)           /***********Main program start**********/
int argc;
char *argv[];
{
   char  specify,COLLIMIT,fname[80],rootname[80];
   struct BUFFER imhead;
   struct fhead_t *fhbuf;
   double factor,sigma,sum, avg,sumsq;
   float medval,medval2;

   int   m, n, idx, isize, ihsz,i,j, k, l,imin,imax,jmin,jmax,ifile;
   float stat[16384];
   FILE *fp1,*fp2;
   double checksum;

   COLLIMIT=specify=FALSE;
   isize=5;

/*  Initialize parameter values  */

   strcpy(fname,"NONE");
   
/*    If enough command line parameters have been entered, read them in    */
   if (argc <2)
   {
      printf("  Enter file name on command line");
      exit(0);
   }
  for (ifile=1; ifile<argc; ++ifile)
  {
    sscanf(argv[ifile],"%s",fname);
 
    if (fname[0]=='-')
    {
       switch (fname[1])
       {
          case 'b':
            sscanf(argv[++ifile],"%i",&imin);
            sscanf(argv[++ifile],"%i",&imax);
            sscanf(argv[++ifile],"%i",&jmin);
            sscanf(argv[++ifile],"%i",&jmax);
            specify=TRUE;
            break;
          case 'l':
            COLLIMIT=TRUE;
            break;
       }
 
    }
    else
    {
    if (readfits(fname,&imhead,image)!=0)
    {
      printf("Error reading FITS file, program terminating.\n");
      exit(1);
   }

   isize=min(isize,32);
   ihsz=isize / 2;

   if (!specify)
   {
      printf("Error - must specify limits with -b\n");
      exit(1);
      imin=0; jmin=0;
      imax=imhead.naxis1;
      jmax=imhead.naxis2;
   } else {
      imin=max(1,min(imin,imhead.naxis1-1));
      jmin=max(1,min(jmin,imhead.naxis2-1));
      imax=max(1,min(imax,imhead.naxis1-1));
      jmax=max(1,min(jmax,imhead.naxis2-1));
      if (imin>imax)
      {
         m=imax;
         imax=imin;
         imin=m;
      }
      if (jmin>jmax)
      {
         m=jmax;
         jmax=jmin;
         jmin=m;
      }
   }

   for (j=jmin-1; j<jmax; j++)
   {
      medval=(image[imax][j]-image[imin-2][j])/(imax-imin+1);
      for (i=imin-1; i<imax; i++)
         image[i][j]=image[imin-2][j]+medval*(i-imin+2);
   }
         
   writefits(fname,&imhead,image);
/*  free up memory for fits buffer: original FITS header lines are discarded,
    but the parameters such as naxis, bitpix, etc. are saved. */

   free_buffer(&imhead);

   }
   }
   exit(0);
 

}     /************************* End main *************************************/
int max(i1,i2)
int i1;
int i2;
{
    if (i1<i2)
        return i2;
    else
        return i1;
}

int min(i1,i2)
int i1;
int i2;
{
    if (i1<i2)
        return i1;
    else
        return i2;
}

float median(a,inum)
float a[];
int inum;
{
    float l,c[16384],b[16384];
    int i,j,k,n,m;

    n=inum;
    for (i=0; i<n; i++)
     b[i]=a[i];

    k=0;
    while (n>1)
    {
       l=b[0]; m=0;
       for (i=0; i<n; i++)
          if (b[i]<l)
          {
             l=b[i];
             m=i;
          }
       c[k++]=l;
       for (i=m; i<n-1; i++)
          b[i]=b[i+1];
       n--;
       if (n==1)
          c[k]=b[0];
    }
    n=inum/2;
    return(c[n]);
     
}
